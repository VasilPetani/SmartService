package com.smarts.SmartS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartSApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartSApplication.class, args);
	}

}
