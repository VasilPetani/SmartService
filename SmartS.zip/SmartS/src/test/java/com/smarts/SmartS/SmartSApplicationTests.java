package com.smarts.SmartS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartSApplicationTests {

	@Test
	void contextLoads() {
	}

}
